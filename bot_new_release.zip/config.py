
#api ключ
token="5279572491:AAFO1Ci-ONPNoy0QljDCyywGI0AJKLLCAPA"

#chat_id канала куда все скидывается
channel = -1001630922776

#chat_id модератора
admin = 1293788323